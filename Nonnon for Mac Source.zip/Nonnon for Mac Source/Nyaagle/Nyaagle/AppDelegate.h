//
//  AppDelegate.h
//  Nyaagle
//
//  Created by のんのん on 2023/02/10.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

