//
//  main.m
//  Nonnon Paint
//
//  Created by のんのん on 2022/09/13.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	@autoreleasepool {
	    // Setup code that might create autoreleased objects goes here.
	}

//NSLog( @"%d : %s", argc, argv[ 1 ] );

	return NSApplicationMain(argc, argv);
}
